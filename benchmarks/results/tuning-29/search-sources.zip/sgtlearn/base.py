"""sklearn-style estimators backed by native Shape Generalized Tree code."""

from __future__ import annotations

import os
import warnings
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from math import ceil, isfinite
from numbers import Integral, Real
from typing import Any

import numpy as np
from ShapeGeneralizedTrees import (
    ClassificationShapeGeneralizedTree,
    RegressionShapeGeneralizedTree,
)
from sklearn.base import BaseEstimator, ClassifierMixin, RegressorMixin
from sklearn.exceptions import NotFittedError
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.utils.validation import check_array, check_is_fitted, check_X_y

from sgtlearn._features import ProcessedFeatures, configure_feature_dict
from sgtlearn._multioutput import (
    as_native_float32,
    as_output_matrix,
    encode_classification_targets,
    label_encoders_as_list,
    native_y_array,
    squeeze_outputs,
    unwrap_classifier_public_attrs,
)
from sgtlearn._weights import (
    effective_sample_weight_classification,
    normalize_sample_weight,
)

__all__ = [
    "BaseShapeCART",
    "ProcessedFeatures",
    "SGTClassifier",
    "SGTRegressor",
    "configure_feature_dict",
]


_MAE_CD_WARNING = (
    "Coordinate descent is disabled for the MAE objective. "
    "Set SGTLEARN_MAE_CD=1 to enable it."
)
_suppress_mae_cd_warning: ContextVar[bool] = ContextVar(
    "suppress_mae_cd_warning", default=False
)


def _warn_if_mae_cd_disabled(criterion: str) -> None:
    if (
        not _suppress_mae_cd_warning.get()
        and str(criterion).strip().lower() in {"absolute_error", "mae"}
        and os.environ.get("SGTLEARN_MAE_CD", "").strip().lower()
        not in {"1", "true", "yes"}
    ):
        warnings.warn(_MAE_CD_WARNING, UserWarning, stacklevel=3)


def _column_names_from_X(X: Any) -> list[str] | None:
    columns = getattr(X, "columns", None)
    if columns is None:
        return None
    return [str(c) for c in columns]


def _as_native_X(X: Any) -> np.ndarray:
    """C-contiguous ``float32`` ``X`` for the native code; rejects infinity.

    A finite value beyond the ``float32`` range passes ``check_array`` but
    becomes ``inf`` here, which the native router would treat like NaN.
    ``fit`` calls it before changing any state, so a rejected refit leaves a
    fitted model intact.
    """
    return as_native_float32(X, "X")


def _as_native_y(y: Any) -> np.ndarray:
    """``float32`` regression targets for the native code; rejects infinity.

    The ``y`` counterpart of :func:`_as_native_X`.
    """
    return native_y_array(as_native_float32(y, "y"), dtype=np.float32)


def _configure_processed_features(
    n_features: int,
    *,
    feature_dict: Mapping[int | str, Sequence[int | str]] | None,
    processed_features: ProcessedFeatures | None,
    column_names: list[str] | None,
) -> ProcessedFeatures:
    if processed_features is not None:
        if not isinstance(processed_features, ProcessedFeatures):
            raise TypeError(
                "processed_features must be a ProcessedFeatures from "
                f"configure_feature_dict; got {type(processed_features).__name__}"
            )
        return processed_features
    return configure_feature_dict(
        n_features,
        feature_dict=feature_dict,
        column_names=column_names,
    )


def _resolve_pairwise_candidates(value: float, n_features: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(  # noqa: TRY004 - sklearn parameters use ValueError
            "pairwise_candidates must be a non-negative int or float"
        )
    if not isfinite(float(value)) or value < 0:
        raise ValueError("pairwise_candidates must be finite and non-negative")
    if isinstance(value, Integral):
        return int(value)
    return ceil(float(value) * n_features)


def _validate_tao_pair_scale(value: float) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(  # noqa: TRY004 - sklearn parameters use ValueError
            "tao_pair_scale must be finite and non-negative"
        )
    try:
        scale = float(value)
    except OverflowError:
        scale = float("inf")
    if not isfinite(scale) or scale < 0:
        raise ValueError("tao_pair_scale must be finite and non-negative")
    return scale


def _validate_int(name: str, value: int, minimum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an int >= {minimum}")
    return int(value)


@contextmanager
def _restore_on_error(est: Any) -> Iterator[None]:
    """Put ``est``'s attributes back if the block raises."""
    state = est.__dict__.copy()
    try:
        yield
    except BaseException:
        est.__dict__ = state
        raise


class _IdentityLabelEncoder(LabelEncoder):
    """``LabelEncoder`` for targets already encoded as ``0 .. n_classes - 1``.

    Meta-estimators (e.g. :class:`~sgtlearn.ensemble.RandomSGForestClassifier`)
    fit a full :class:`~sklearn.preprocessing.LabelEncoder` once and train base
    trees on integer ``y``. Each base tree holds the meta-estimator's original
    ``classes_``, so :meth:`transform` passes the integer codes through and
    :meth:`inverse_transform` maps them back to the original labels.
    """

    def __init__(self, classes_: np.ndarray) -> None:
        self.classes_ = np.asarray(classes_)

    def fit(self, y: np.ndarray) -> _IdentityLabelEncoder:
        raise NotImplementedError(
            "_IdentityLabelEncoder is built with preset classes_; "
            "fit the enclosing meta-estimator instead."
        )

    def transform(self, y: np.ndarray) -> np.ndarray:
        return np.asarray(y, dtype=np.int64).ravel()

    def inverse_transform(self, y: np.ndarray) -> np.ndarray:
        return super().inverse_transform(y)


# TODO: flesh out as abstract class so export methods can have a proper type instead of Any
class BaseShapeCART(BaseEstimator):
    """Shared sklearn ``BaseEstimator`` hook point for shape-generalized trees.

    Subclasses own the native backend handle (``_est``) and validation rules.
    """

    _tao_refined_: bool = False

    @property
    def feature_importances_(self) -> np.ndarray:
        """Normalized per-feature importances from the fitted tree.

        Length matches the number of logical features passed to ``fit``
        (one-to-one with :attr:`processed_features_`). Available only after
        training with ``tao_n_runs=0`` (the default ``tao_n_runs=10`` runs TAO)
        and no later TAO refinement; otherwise raises ``AttributeError``. Warns
        when the tree has pair nodes, whose gain is split equally between both
        features.
        """
        check_is_fitted(self, attributes=("_est",))
        if getattr(self, "_tao_refined_", False):
            raise AttributeError(
                "feature_importances_ is unavailable after TAO refinement; "
                "use permutation importance on held-out data instead."
            )
        if getattr(self._est, "has_pair_nodes", False):
            warnings.warn(
                "Pair-node impurity gain is split equally between both features; "
                "this attribution is only a bookkeeping convention.",
                UserWarning,
                stacklevel=2,
            )
        return np.asarray(self._est.feature_importance, dtype=np.float64).ravel()

    @property
    def processed_features_(self) -> ProcessedFeatures:
        """Resolved logical features used at fit, aligned with importances.

        ``features[i]`` and ``logical_names[i]`` correspond to
        ``feature_importances_[i]``. ``logical_names`` are the ``feature_dict``
        keys (stringified); each omitted column ``i`` is named ``str(i)``.
        """
        check_is_fitted(self, attributes=("_processed_features",))
        return self._processed_features


def _normalize_tree_export(tree: dict) -> dict:
    """Normalize native ``tree_export`` payloads for Python consumers.

    Internal nodes may include a trailing ``+inf`` threshold sentinel and/or a
    trailing NaN routing bin in ``bin_to_partition``. Plotting and introspection
    expect finite numeric bins only (``len(thresholds) + 1`` entries); NaN
    routing is exposed separately via ``nan_prediction_partition``.
    """
    for node in tree.get("nodes", []):
        if node.get("is_leaf", True):
            continue
        if node.get("routing_kind") == "pair":
            continue
        if node.get("is_categorical"):
            b2p = node.get("bin_to_partition")
            if not b2p:
                continue
            node["nan_prediction_partition"] = b2p[-1]
            node["bin_to_partition"] = b2p[:-1]
            bc = node.get("bin_categories")
            if bc is not None and len(bc) == len(b2p):
                node["bin_categories"] = bc[:-1]
            for key in ("bin_sample_counts", "bin_counts", "bin_weights"):
                vals = node.get(key)
                if vals is not None and len(vals) == len(b2p):
                    node[key] = vals[:-1]
            continue
        thresholds = node.get("thresholds")
        if thresholds is not None:
            while thresholds and thresholds[-1] == np.inf:
                thresholds.pop()
        b2p = node.get("bin_to_partition")
        th = thresholds or []
        if not b2p or len(b2p) != len(th) + 2:
            continue
        node["nan_prediction_partition"] = b2p[-1]
        node["bin_to_partition"] = b2p[:-1]
        for key in ("bin_sample_counts", "bin_counts", "bin_weights"):
            vals = node.get(key)
            if vals is not None and len(vals) == len(b2p):
                node[key] = vals[:-1]
    return tree


def _renormalize_proba(proba: Any) -> np.ndarray:
    """Cast native float32 probabilities to float64 and renormalize each row.

    The cast alone leaves row sums ~1e-8 from one; rows summing to zero
    (zero-weight leaves) are left unchanged.
    """
    p = np.asarray(proba, dtype=np.float64)
    sums = p.sum(axis=1, keepdims=True)
    return np.divide(p, sums, out=p, where=sums > 0)


class SGTClassifier(ClassifierMixin, BaseShapeCART):
    """Shape Generalized Tree classifier.

    A decision tree where each internal node applies a learnable, axis-aligned
    *shape function*. By default the shape function is a depth-limited inner
    tree over one logical feature; ``pairwise_candidates > 0`` also lets it use
    an ordinary axis-aligned CART over two logical features. The outer tree
    routes those bins into at most ``num_partitions`` children. Training is
    performed by the native ShapeCART C++ trainer exposed through
    ``ClassificationShapeGeneralizedTree``.

    The estimator follows the ``scikit-learn`` ``ClassifierMixin`` contract and
    is compatible with sklearn pipelines, cross-validators, and metaestimators.

    Parameters
    ----------
    criterion : {"gini", "entropy", "log_loss"}, default="gini"
        Impurity criterion used both to grow each node's inner shape-function
        tree and to score outer-tree splits (``"log_loss"`` is an alias of
        ``"entropy"``).
    num_partitions : int, default=2
        Maximum number of branches each outer split fans out into; a split may
        have fewer children. Must be at least ``2``. ``2`` reproduces a
        standard binary tree; larger values yield the ``SGT_K`` multi-way
        variant.
    max_depth : int, optional
        Maximum depth of the *outer* tree. ``None`` (default) means grow until
        another stopping criterion fires.
    max_leaf_nodes : int, optional
        Maximum number of leaves in the outer tree. ``None`` means unlimited.
    min_samples_leaf : int, default=1
        Minimum number of training samples required at an outer leaf.
    min_impurity_decrease : float, default=0.0
        Constant nonnegative cost subtracted from total sample-weighted,
        output-averaged impurity improvement. An outer split must have finite
        improvement after all costs strictly greater than double epsilon.
    inner_max_depth : int or None, default=None
        Maximum depth of the *inner* tree that defines the shape function on
        each feature. ``1`` corresponds to a standard CART threshold split;
        larger values produce richer shapes. ``None`` means unlimited depth,
        so ``inner_max_leaf_nodes`` alone controls the inner tree size.
    inner_max_leaf_nodes : int, default=8
        Maximum number of bins (leaves) the inner tree may form on a feature.
        The inner tree grows best-first until this limit. Both limits apply
        together: depth ``d`` allows at most ``2**d`` leaves, so setting
        ``inner_max_depth`` with ``2**d <= inner_max_leaf_nodes`` makes the
        leaf limit ineffective.
    inner_min_samples_leaf : int, default=1
        Minimum samples per inner-tree leaf.
    inner_min_impurity_decrease : float, default=0.0
        Minimum impurity decrease required to accept an inner split.
    coordinate_descent_max_iters : int, default=20
        Maximum coordinate-descent iterations used to refine the bin-to-branch
        assignment after the inner tree is built.
    coordinate_descent_patience : int, default=5
        Number of non-improving iterations tolerated before coordinate descent
        terminates early.
    random_state : int, optional, default=42
        Seed forwarded to the native trainer. ``None`` is treated as ``42``.
    max_features : int, float, {"sqrt", "log2"} or None, default=None
        Number of logical features sampled (without replacement) when
        searching for a split:

        - ``None``: use all ``n_logical_features`` features.
        - ``int k >= 1``: use ``min(k, n_logical_features)`` features.
        - ``float c in (0, 1]``: use ``max(1, int(c * n_logical_features))`` features.
        - ``"sqrt"``: use ``max(1, int(sqrt(n_logical_features)))`` features.
        - ``"log2"``: use ``max(1, int(log2(n_logical_features)))`` features.

        String values are case-insensitive in the native binding.
    pairwise_candidates : int or float, default=0
        Maximum retained feature pairs fitted per node. An integer is an
        absolute limit; a float resolves to ``ceil(value * n_logical_features)``.
        Zero preserves univariate-only training.
    pairwise_penalty : float, default=0.0
        Constant nonnegative cost subtracted from a fitted pair's total
        sample-weighted, output-averaged impurity improvement.
    branching_penalty : float, default=0.0
        Constant nonnegative cost per additional occupied child beyond two.
    tao_n_runs : int, default=10
        Maximum number of Tree Alternating Optimization (TAO) sweeps run at the
        end of :meth:`fit` (see :func:`~sgtlearn.tao.TAO_refine`); sweeps stop
        early once one makes no change. ``0`` disables TAO; any positive value
        makes ``feature_importances_`` unavailable.
    tao_lambda : float, default=0.0
        TAO per-sample complexity rate: at each internal node a non-constant
        routing rule must beat the constant rule by more than ``tao_lambda``
        times the number of samples reaching the node (weighted reward units).
    tao_pair_scale : float, default=1.1
        Multiplier applied to ``tao_lambda`` for pair routers during TAO.
    class_weight : dict, list of dict, or None, default=None
        Per-class multipliers. A single mapping applies to every output; for
        multi-output ``y`` of shape ``(n_samples, n_outputs)``, pass a list of
        mappings (one per output). Combined with ``sample_weight`` into one
        weight vector (product across outputs), matching sklearn.

    Attributes
    ----------
    classes_ : ndarray or list of ndarray
        Class labels. For a single target this is a 1-D array; for multi-output
        ``y`` it is a list of per-output class arrays (``predict_proba`` returns
        a matching list of probability matrices).
    n_classes_ : int or list of int
        Number of classes (scalar or one entry per output).
    n_outputs_ : int
        Number of target columns (``1`` for a 1-D ``y``).
    n_features_in_ : int
        Number of features in ``X`` passed to :meth:`fit`.
    feature_names_in_ : ndarray of shape (n_features,) or None
        Column names, converted to ``str``, of an ``X`` with a ``columns``
        attribute (e.g. a pandas ``DataFrame``) seen during :meth:`fit`;
        ``None`` otherwise.
    feature_importances_ : ndarray of shape (n_logical_features,)
        Normalized impurity-based importances from the fitted tree. Index
        ``i`` corresponds to :attr:`processed_features_` entry ``i`` (same
        order as the logical features passed to the native trainer). Raises
        ``AttributeError`` after TAO refinement, which runs by default
        (``tao_n_runs=10``); fit with ``tao_n_runs=0`` to use it.
    processed_features_ : ProcessedFeatures
        Resolved logical features used at :meth:`fit`. ``features[i]`` and
        ``logical_names[i]`` align with ``feature_importances_[i]``.
        ``logical_names`` are stringified ``feature_dict`` keys (an
        auto-filled column ``i`` is named ``str(i)``).

    Notes
    -----
    Internally, single- and multi-output training share one path: ``y`` is
    always handled as ``(n_samples, n_outputs)`` (with ``n_outputs=1`` for a
    vector target). Outer impurity averages across outputs. ``X`` is cast to
    C-contiguous ``float32`` and ``y`` to ``uint64`` before the native trainer.
    Sparse input is not supported. NaN in ``X`` is handled by the native
    trainer: shape functions are fit on finite values, and each univariate
    outer node learns a ``nan_prediction_partition``, the child that best fits
    its training NaNs (or the child with the most training samples when the
    node saw none). At inference, missing values go to that child regardless
    of where the largest finite values go. Pair nodes route missing values
    through their pair router: a pair-tree split sends values missing on its
    axis to a dedicated branch when its training samples had any, otherwise
    to the larger finite child. Infinity in ``X`` and ``sample_weight`` is
    rejected, as are finite values that overflow ``float32`` (e.g. ``1e39``),
    including ``sample_weight * class_weight``.

    References
    ----------
    Upadhya, N. and Cohen, E. "Empowering Decision Trees via Shape Function
    Branching." NeurIPS, 2025.

    See Also
    --------
    SGTRegressor : Regression counterpart.
    sgtlearn.RandomSGForestClassifier : Bootstrap ensemble over
        :class:`SGTClassifier`.

    Examples
    --------
    >>> from sklearn.datasets import make_classification, make_multilabel_classification
    >>> from sgtlearn import SGTClassifier
    >>> X, y = make_classification(n_samples=500, random_state=0)
    >>> clf = SGTClassifier(max_depth=4, random_state=42).fit(X, y)
    >>> clf.predict(X[:5]).shape
    (5,)
    >>> Xm, ym = make_multilabel_classification(
    ...     n_samples=200, n_classes=3, n_labels=1, random_state=0
    ... )
    >>> # Multi-output integer labels also work (one tree, joint impurity).
    >>> clf_m = SGTClassifier(inner_max_depth=1, tao_n_runs=0, random_state=0)
    >>> clf_m.fit(Xm, ym[:, :2]).predict(Xm[:3]).shape
    (3, 2)
    """

    def __init__(
        self,
        *,
        criterion: str = "gini",
        num_partitions: int = 2,
        max_depth: int | None = None,
        max_leaf_nodes: int | None = None,
        min_samples_leaf: int = 1,
        min_impurity_decrease: float = 0.0,
        inner_max_depth: int | None = None,
        inner_max_leaf_nodes: int = 8,
        inner_min_samples_leaf: int = 1,
        inner_min_impurity_decrease: float = 0.0,
        coordinate_descent_max_iters: int = 20,
        coordinate_descent_patience: int = 5,
        random_state: int | None = 42,
        max_features: float | str | None = None,
        pairwise_candidates: float = 0,
        pairwise_penalty: float = 0.0,
        branching_penalty: float = 0.0,
        class_weight: Mapping[Any, float] | Sequence[Mapping[Any, float]] | None = None,
        tao_n_runs: int = 10,
        tao_lambda: float = 0.0,
        tao_pair_scale: float = 1.1,
    ) -> None:
        """Store hyperparameters; training happens in :meth:`fit`."""
        self.criterion = criterion
        self.num_partitions = num_partitions
        self.max_depth = max_depth
        self.max_leaf_nodes = max_leaf_nodes
        self.min_samples_leaf = min_samples_leaf
        self.min_impurity_decrease = min_impurity_decrease
        self.inner_max_depth = inner_max_depth
        self.inner_max_leaf_nodes = inner_max_leaf_nodes
        self.inner_min_samples_leaf = inner_min_samples_leaf
        self.inner_min_impurity_decrease = inner_min_impurity_decrease
        self.coordinate_descent_max_iters = coordinate_descent_max_iters
        self.coordinate_descent_patience = coordinate_descent_patience
        self.random_state = random_state
        self.max_features = max_features
        self.pairwise_candidates = pairwise_candidates
        self.pairwise_penalty = pairwise_penalty
        self.branching_penalty = branching_penalty
        self.class_weight = class_weight

        self.tao_n_runs = tao_n_runs
        self.tao_lambda = tao_lambda
        self.tao_pair_scale = tao_pair_scale
        self._est: Any = None
        self._le: Any = None
        self.classes_: Any | None = None
        self.n_classes_: Any | None = None
        self.n_outputs_: int = 1
        self.n_features_in_: int | None = None
        self.feature_names_in_: np.ndarray | None = None

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        sample_weight: np.ndarray | None = None,
        *,
        feature_dict: Mapping[int | str, Sequence[int | str]] | None = None,
        processed_features: ProcessedFeatures | None = None,
        check_input: bool = True,
    ) -> SGTClassifier:
        """Fit the tree on ``X`` and class labels ``y``.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Training features.
        y : array-like of shape (n_samples,) or (n_samples, n_outputs)
            Target class labels. Multi-output ``y`` trains one joint tree;
            outer impurity is averaged across outputs.
        sample_weight : array-like of shape (n_samples,), optional
            Per-sample weights.
        feature_dict : mapping, optional
            ``{logical_name: [columns]}`` grouping of columns into logical
            features. Keys are ``int`` or ``str`` logical names. Values are
            column indices (``int``) or column names (``str``); names require a
            pandas ``DataFrame`` ``X``. A group of more than one column is
            treated as a single **categorical** feature (routed through the
            one-hot inner discretizer); singletons are **continuous**. Columns not mentioned default to continuous
            singletons. See :func:`~sgtlearn.configure_feature_dict` for the
            full resolution rules.
        processed_features : ProcessedFeatures, optional
            Pre-resolved features from :func:`configure_feature_dict` (for
            ensembles that should resolve features once).
        check_input : bool, default=True
            If ``False``, ``X`` and ``y`` are not validated (for callers that
            already ran :func:`~sklearn.utils.check_X_y`). The caller must then
            pass ``y`` as integer codes ``0 .. n_classes - 1`` and preset
            ``classes_`` and ``n_classes_``.
        """
        column_names = _column_names_from_X(X)

        # Validate and fit into locals; ``self`` changes only once the new
        # tree is trained (and is restored if TAO then fails), so a rejected
        # refit leaves a fitted model intact.
        if check_input:
            X, y = check_X_y(
                X,
                y,
                accept_sparse=False,
                dtype=np.float64,
                ensure_all_finite="allow-nan",
                multi_output=True,
            )
            X32 = _as_native_X(X)
            y_enc, encoders, classes_list, n_classes_list = (
                encode_classification_targets(y)
            )
            n_outputs = y_enc.shape[1]
            if any(k < 2 for k in n_classes_list):
                raise ValueError(
                    "SGTClassifier requires at least two classes per output."
                )
        else:
            if self.classes_ is None or self.n_classes_ is None:
                raise ValueError(
                    "SGTClassifier.fit(check_input=False) requires classes_ and "
                    "n_classes_ to be set by the caller before fit."
                )
            X = np.asarray(X)
            X32 = _as_native_X(X)
            y2, n_outputs = as_output_matrix(y)
            if n_outputs == 1 and not isinstance(self.classes_, (list, tuple)):
                preset = [_IdentityLabelEncoder(np.asarray(self.classes_))]
                n_classes_list = [int(self.n_classes_)]
            else:
                classes_seq = list(self.classes_)
                n_classes_seq = list(np.atleast_1d(self.n_classes_))
                if len(classes_seq) != n_outputs or len(n_classes_seq) != n_outputs:
                    raise ValueError(
                        "SGTClassifier.fit(check_input=False) requires one "
                        f"classes_ and n_classes_ entry per output; y has "
                        f"{n_outputs} outputs."
                    )
                preset = [_IdentityLabelEncoder(np.asarray(c)) for c in classes_seq]
                n_classes_list = [int(k) for k in n_classes_seq]
            if any(k < 2 for k in n_classes_list):
                raise ValueError(
                    "SGTClassifier requires at least two classes per output."
                )
            y_enc, encoders, classes_list, n_classes_list = (
                encode_classification_targets(y2, encoders=preset)
            )
            if y_enc.shape[0] != X.shape[0]:
                raise ValueError("X and y must have the same number of samples.")
        le, classes, n_classes, n_classes_native = unwrap_classifier_public_attrs(
            encoders, classes_list, n_classes_list, n_outputs
        )

        sw: np.ndarray | None = None
        if self.class_weight is not None:
            sw = effective_sample_weight_classification(
                sample_weight, y_enc, self.class_weight, classes_list
            )
        else:
            sw = normalize_sample_weight(sample_weight, X.shape[0])

        n_features = X.shape[1]
        if column_names is None:
            column_names = _column_names_from_X(X)

        processed_features = _configure_processed_features(
            n_features,
            feature_dict=feature_dict,
            processed_features=processed_features,
            column_names=column_names,
        )
        resolved_pairwise_candidates = _resolve_pairwise_candidates(
            self.pairwise_candidates, len(processed_features.features)
        )
        for name in ("min_impurity_decrease", "pairwise_penalty", "branching_penalty"):
            value = getattr(self, name)
            if not isinstance(value, Real) or not isfinite(float(value)) or value < 0:
                raise ValueError(f"{name} must be finite and non-negative")
        tao_pair_scale = _validate_tao_pair_scale(self.tao_pair_scale)
        tao_n_runs = _validate_int("tao_n_runs", self.tao_n_runs, 0)

        outer_depth = 0 if self.max_depth is None else int(self.max_depth)
        outer_leaves = 0 if self.max_leaf_nodes is None else int(self.max_leaf_nodes)
        inner_depth = 0 if self.inner_max_depth is None else int(self.inner_max_depth)
        inner_leaves = (
            0 if self.inner_max_leaf_nodes is None else int(self.inner_max_leaf_nodes)
        )

        est = ClassificationShapeGeneralizedTree(
            str(self.criterion),
            n_classes_native,
            int(self.num_partitions),
            int(self.min_samples_leaf),
            float(self.min_impurity_decrease),
            outer_depth,
            outer_leaves,
            int(self.inner_min_samples_leaf),
            float(self.inner_min_impurity_decrease),
            inner_depth,
            inner_leaves,
            int(self.coordinate_descent_max_iters),
            int(self.coordinate_descent_patience),
            int(42 if self.random_state is None else self.random_state),
            self.max_features,
            resolved_pairwise_candidates,
            float(self.pairwise_penalty),
            float(self.branching_penalty),
        )

        y_u = native_y_array(y_enc, dtype=np.uint64)
        est.fit(X32, y_u, sample_weight=sw, features=processed_features.to_native())

        with _restore_on_error(self):
            self.n_outputs_ = n_outputs
            self._le = le
            self.classes_ = classes
            self.n_classes_ = n_classes
            self.n_features_in_ = n_features
            self.feature_names_in_ = (
                np.asarray(column_names, dtype=object)
                if column_names is not None
                else None
            )
            self._processed_features = processed_features
            self._est = est
            self._tao_refined_ = False
            if tao_n_runs > 0:
                from sgtlearn.tao import TAO_refine

                TAO_refine(
                    self,
                    X32,
                    y,
                    # raw weights: TAO applies class_weight itself
                    sample_weight=sample_weight,
                    check_input=check_input,
                    n_runs=tao_n_runs,
                    lambda_=self.tao_lambda,
                    tao_pair_scale=tao_pair_scale,
                )
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class labels (via the fitted label encoder)."""

        check_is_fitted(self, attributes=("_est", "_le"))
        X32 = _as_native_X(
            check_array(
                X,
                accept_sparse=False,
                dtype=np.float64,
                ensure_all_finite="allow-nan",
            )
        )
        if X32.shape[1] != self.n_features_in_:
            raise ValueError(
                f"X has {X32.shape[1]} features, but SGTClassifier is expecting "
                f"{self.n_features_in_} features as in fit."
            )
        preds = np.asarray(self._est.predict(X32))
        encoders = label_encoders_as_list(self._le, self.n_outputs_)
        if preds.ndim == 1:
            preds = preds.reshape(-1, 1)
        cols = [
            encoders[o].inverse_transform(preds[:, o]) for o in range(self.n_outputs_)
        ]
        return squeeze_outputs(np.column_stack(cols), self.n_outputs_)

    def predict_proba(self, X: np.ndarray) -> Any:
        """Class probabilities aligned with :attr:`classes_`.

        Single output: an array of shape ``(n_samples, n_classes)``.
        Multi-output: a list of such arrays, one per output (sklearn
        convention).
        """

        check_is_fitted(self, attributes=("_est", "_le"))
        X = check_array(
            X, accept_sparse=False, dtype=np.float64, ensure_all_finite="allow-nan"
        )
        if X.shape[1] != self.n_features_in_:
            raise ValueError(
                f"X has {X.shape[1]} features, but SGTClassifier is expecting "
                f"{self.n_features_in_} features as in fit."
            )
        X32 = _as_native_X(X)
        # Native: single (n_samples, n_classes) array, or a list of such arrays
        # per output, aligned with encoded labels 0..K-1 for each output.
        proba = self._est.predict_proba(X32)
        if self.n_outputs_ == 1:
            return _renormalize_proba(proba)
        return [_renormalize_proba(p) for p in proba]

    def tree_export(self) -> dict:
        """Return a flat dict snapshot of the fitted tree.

        Consumed by :func:`~sgtlearn.plot_tree` and :func:`~sgtlearn.export_text`.
        Keys: ``num_partitions``, ``num_nodes``, ``root_index``, ``num_classes`` (one
        entry per output), ``num_outputs``, ``classes_per_output``,
        ``criterion``, ``nodes`` (list of per-node dicts).
        """
        check_is_fitted(self, attributes=("_est", "_le"))
        if self._est is None:
            raise NotFittedError("This SGTClassifier instance is not fitted yet.")
        return _normalize_tree_export(self._est.tree_export())


class SGTRegressor(RegressorMixin, BaseShapeCART):
    """Shape Generalized Tree regressor.

    Regression analogue of :class:`SGTClassifier`. Each internal node applies a
    learnable shape function: an inner univariate tree by default, or an
    ordinary axis-aligned two-feature CART when bivariate branching is enabled.
    The outer tree routes samples through the resulting bins. Training is
    performed by the native ShapeCART C++ trainer exposed through
    ``RegressionShapeGeneralizedTree``.

    Compatible with the ``scikit-learn`` ``RegressorMixin`` contract.

    Parameters
    ----------
    criterion : {"squared_error", "mse", "absolute_error", "mae"}, default="squared_error"
        Loss used both to grow each node's inner shape-function tree and to
        score outer-tree splits. ``"mse"`` and ``"mae"`` are accepted as
        aliases.
    num_partitions : int, default=2
        Maximum number of branches each outer split fans out into; a split may
        have fewer children. Must be at least ``2``. ``2`` reproduces a
        standard binary tree; larger values yield the ``SGT_K`` multi-way
        variant.
    max_depth : int, optional
        Maximum depth of the outer tree. ``None`` means grow until another
        stopping criterion fires.
    max_leaf_nodes : int, optional
        Maximum number of leaves in the outer tree. ``None`` means unlimited.
    min_samples_leaf : int, default=1
        Minimum number of samples required at an outer leaf.
    min_impurity_decrease : float, default=0.0
        Constant nonnegative cost subtracted from total sample-weighted,
        output-averaged impurity improvement. An outer split must have finite
        improvement after all costs strictly greater than double epsilon.
    inner_max_depth : int or None, default=None
        Maximum depth of the *inner* tree that defines the shape function on
        each feature. ``1`` corresponds to a standard CART threshold split;
        larger values produce richer shapes. ``None`` means unlimited depth,
        so ``inner_max_leaf_nodes`` alone controls the inner tree size.
    inner_max_leaf_nodes : int, default=8
        Maximum number of bins (leaves) the inner tree may form on a feature.
        The inner tree grows best-first until this limit. Both limits apply
        together: depth ``d`` allows at most ``2**d`` leaves, so setting
        ``inner_max_depth`` with ``2**d <= inner_max_leaf_nodes`` makes the
        leaf limit ineffective.
    inner_min_samples_leaf : int, default=1
        Minimum samples per inner-tree leaf.
    inner_min_impurity_decrease : float, default=0.0
        Minimum impurity decrease required to accept an inner split.
    coordinate_descent_max_iters : int, default=20
        Maximum coordinate-descent iterations used to refine the bin-to-branch
        assignment after the inner tree is built.
    coordinate_descent_patience : int, default=5
        Number of non-improving iterations tolerated before coordinate descent
        terminates early.
    random_state : int, optional, default=42
        Seed forwarded to the native trainer. ``None`` is treated as ``42``.
    max_features : int, float, {"sqrt", "log2"} or None, default=None
        Per-split feature subsampling. Same semantics as
        :class:`SGTClassifier`.
    pairwise_candidates : int or float, default=0
        Maximum retained feature pairs fitted per node. An integer is an
        absolute limit; a float resolves to ``ceil(value * n_logical_features)``.
        Zero preserves univariate-only training.
    pairwise_penalty : float, default=0.0
        Constant nonnegative cost subtracted from a fitted pair's total
        sample-weighted, output-averaged impurity improvement.
    branching_penalty : float, default=0.0
        Constant nonnegative cost per additional occupied child beyond two.
    tao_n_runs : int, default=10
        Maximum number of Tree Alternating Optimization (TAO) sweeps run at the
        end of :meth:`fit` (see :func:`~sgtlearn.tao.TAO_refine`); sweeps stop
        early once one makes no change. ``0`` disables TAO; any positive value
        makes ``feature_importances_`` unavailable.
    tao_lambda : float, default=0.0
        TAO per-sample complexity rate: at each internal node a non-constant
        routing rule must beat the constant rule by more than ``tao_lambda``
        times the number of samples reaching the node (weighted reward units).
    tao_pair_scale : float, default=1.1
        Multiplier applied to ``tao_lambda`` for pair routers during TAO.

    Attributes
    ----------
    n_outputs_ : int
        Number of target columns (``1`` for a 1-D ``y``).
    n_features_in_ : int
        Number of features seen during :meth:`fit`.
    feature_names_in_ : ndarray of shape (n_features,) or None
        Column names, converted to ``str``, of an ``X`` with a ``columns``
        attribute (e.g. a pandas ``DataFrame``) seen during :meth:`fit`;
        ``None`` otherwise.
    feature_importances_ : ndarray of shape (n_logical_features,)
        Normalized impurity-based importances from the fitted tree. Index
        ``i`` corresponds to :attr:`processed_features_` entry ``i`` (same
        order as the logical features passed to the native trainer). Raises
        ``AttributeError`` after TAO refinement, which runs by default
        (``tao_n_runs=10``); fit with ``tao_n_runs=0`` to use it.
    processed_features_ : ProcessedFeatures
        Resolved logical features used at :meth:`fit`. ``features[i]`` and
        ``logical_names[i]`` align with ``feature_importances_[i]``.
        ``logical_names`` are stringified ``feature_dict`` keys (an
        auto-filled column ``i`` is named ``str(i)``).

    Notes
    -----
    Internally, single- and multi-output training share one path: ``y`` is
    always handled as ``(n_samples, n_outputs)``. Outer impurity averages across
    outputs. ``X`` and ``y`` are cast to C-contiguous ``float32`` before the
    native trainer. Sparse input is not supported. NaN in ``X`` is handled by
    the native trainer: shape functions are fit on finite values, and each
    univariate outer node learns a ``nan_prediction_partition``, the child
    that best fits its training NaNs (or the child with the most training
    samples when the node saw none). At inference, missing values go to that
    child regardless of where the largest finite values go. Pair nodes route
    missing values through their pair router: a pair-tree split sends values
    missing on its axis to a dedicated branch when its training samples had
    any, otherwise to the larger finite child. Infinity in ``X``, ``y`` and
    ``sample_weight`` is rejected, as are finite values that overflow
    ``float32`` (e.g. ``1e39``).

    For each candidate branch count, ``squared_error``/``mse`` starts coordinate
    descent from a weighted k-means clustering of the bin means, or from the
    inner tree's root split when the root split's impurity is no higher.
    ``absolute_error``/``mae`` scores the root split and round-robin seeds
    without coordinate descent unless the ``SGTLEARN_MAE_CD`` environment
    variable is set to ``1``; :meth:`fit` warns while it is unset.
    Across all scored trials, the lowest-impurity feasible assignment is kept
    for each number of occupied branches.

    References
    ----------
    Upadhya, N. and Cohen, E. "Empowering Decision Trees via Shape Function
    Branching." NeurIPS, 2025.

    See Also
    --------
    SGTClassifier : Classification counterpart.
    sgtlearn.RandomSGForestRegressor : Bootstrap ensemble over
        :class:`SGTRegressor`.

    Examples
    --------
    >>> from sklearn.datasets import make_regression
    >>> from sgtlearn import SGTRegressor
    >>> X, y = make_regression(n_samples=500, random_state=0)
    >>> reg = SGTRegressor(max_depth=4, random_state=42).fit(X, y)
    >>> reg.predict(X[:5]).shape
    (5,)
    """

    def __init__(
        self,
        *,
        criterion: str = "squared_error",
        num_partitions: int = 2,
        max_depth: int | None = None,
        max_leaf_nodes: int | None = None,
        min_samples_leaf: int = 1,
        min_impurity_decrease: float = 0.0,
        inner_max_depth: int | None = None,
        inner_max_leaf_nodes: int = 8,
        inner_min_samples_leaf: int = 1,
        inner_min_impurity_decrease: float = 0.0,
        coordinate_descent_max_iters: int = 20,
        coordinate_descent_patience: int = 5,
        random_state: int | None = 42,
        max_features: float | str | None = None,
        pairwise_candidates: float = 0,
        pairwise_penalty: float = 0.0,
        branching_penalty: float = 0.0,
        tao_n_runs: int = 10,
        tao_lambda: float = 0.0,
        tao_pair_scale: float = 1.1,
    ) -> None:
        self.criterion = criterion
        self.num_partitions = num_partitions
        self.max_depth = max_depth
        self.max_leaf_nodes = max_leaf_nodes
        self.min_samples_leaf = min_samples_leaf
        self.min_impurity_decrease = min_impurity_decrease
        self.inner_max_depth = inner_max_depth
        self.inner_max_leaf_nodes = inner_max_leaf_nodes
        self.inner_min_samples_leaf = inner_min_samples_leaf
        self.inner_min_impurity_decrease = inner_min_impurity_decrease
        self.coordinate_descent_max_iters = coordinate_descent_max_iters
        self.coordinate_descent_patience = coordinate_descent_patience
        self.random_state = random_state
        self.max_features = max_features
        self.pairwise_candidates = pairwise_candidates
        self.pairwise_penalty = pairwise_penalty
        self.branching_penalty = branching_penalty
        self.tao_n_runs = tao_n_runs
        self.tao_lambda = tao_lambda
        self.tao_pair_scale = tao_pair_scale
        self._est: Any = None
        self.n_outputs_: int = 1
        self.n_features_in_: int | None = None
        self.feature_names_in_: np.ndarray | None = None

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        sample_weight: np.ndarray | None = None,
        *,
        feature_dict: Mapping[int | str, Sequence[int | str]] | None = None,
        processed_features: ProcessedFeatures | None = None,
        check_input: bool = True,
    ) -> SGTRegressor:
        """Fit the tree on ``X`` and continuous targets ``y``.

        Parameters
        ----------
        X : array-like of shape (n_samples, n_features)
            Training features.
        y : array-like of shape (n_samples,) or (n_samples, n_outputs)
            Target values. Multi-output ``y`` trains one joint tree; outer loss
            is averaged across outputs.
        sample_weight : array-like of shape (n_samples,), optional
            Per-sample weights.
        feature_dict : mapping, optional
            ``{logical_name: [columns]}`` grouping of columns into logical
            features. Keys are ``int`` or ``str`` logical names. Values are
            column indices (``int``) or column names (``str``); names require a
            pandas ``DataFrame`` ``X``. A group of more than one column is
            treated as a single **categorical** feature (routed through the
            one-hot inner discretizer); singletons are **continuous**. Columns not mentioned default to continuous
            singletons. See :func:`~sgtlearn.configure_feature_dict` for the
            full resolution rules.
        processed_features : ProcessedFeatures, optional
            Pre-resolved features from :func:`configure_feature_dict`.
        check_input : bool, default=True
            If ``False``, ``X`` and ``y`` are not validated (for callers that
            already ran :func:`~sklearn.utils.check_X_y`).
        """
        column_names = _column_names_from_X(X)

        # Validate and fit into locals; ``self`` changes only once the new
        # tree is trained (and is restored if TAO then fails), so a rejected
        # refit leaves a fitted model intact.
        if check_input:
            X, y = check_X_y(
                X,
                y,
                accept_sparse=False,
                dtype=np.float64,
                ensure_all_finite="allow-nan",
                y_numeric=True,
                multi_output=True,
            )
            if np.isnan(np.asarray(y, dtype=np.float64)).any():
                raise ValueError("Input y contains NaN.")
        X32 = _as_native_X(X)
        y2, n_outputs = as_output_matrix(np.asarray(y))
        _as_native_y(y2)  # Preserve native-range validation before scaling.
        sw = normalize_sample_weight(sample_weight, X.shape[0])
        target_scaler = StandardScaler().fit(y2, sample_weight=sw)
        y32 = _as_native_y(target_scaler.transform(y2))
        n_features = X.shape[1]
        if column_names is None:
            column_names = _column_names_from_X(X)

        processed_features = _configure_processed_features(
            n_features,
            feature_dict=feature_dict,
            processed_features=processed_features,
            column_names=column_names,
        )
        resolved_pairwise_candidates = _resolve_pairwise_candidates(
            self.pairwise_candidates, len(processed_features.features)
        )
        for name in ("min_impurity_decrease", "pairwise_penalty", "branching_penalty"):
            value = getattr(self, name)
            if not isinstance(value, Real) or not isfinite(float(value)) or value < 0:
                raise ValueError(f"{name} must be finite and non-negative")
        tao_pair_scale = _validate_tao_pair_scale(self.tao_pair_scale)
        tao_n_runs = _validate_int("tao_n_runs", self.tao_n_runs, 0)

        outer_depth = 0 if self.max_depth is None else int(self.max_depth)
        outer_leaves = 0 if self.max_leaf_nodes is None else int(self.max_leaf_nodes)
        inner_depth = 0 if self.inner_max_depth is None else int(self.inner_max_depth)
        inner_leaves = (
            0 if self.inner_max_leaf_nodes is None else int(self.inner_max_leaf_nodes)
        )

        est = RegressionShapeGeneralizedTree(
            str(self.criterion),
            int(self.num_partitions),
            int(self.min_samples_leaf),
            float(self.min_impurity_decrease),
            outer_depth,
            outer_leaves,
            int(self.inner_min_samples_leaf),
            float(self.inner_min_impurity_decrease),
            inner_depth,
            inner_leaves,
            int(self.coordinate_descent_max_iters),
            int(self.coordinate_descent_patience),
            int(42 if self.random_state is None else self.random_state),
            self.max_features,
            resolved_pairwise_candidates,
            float(self.pairwise_penalty),
            float(self.branching_penalty),
        )

        _warn_if_mae_cd_disabled(self.criterion)
        est.fit(X32, y32, sample_weight=sw, features=processed_features.to_native())

        with _restore_on_error(self):
            self.n_outputs_ = n_outputs
            self._target_scaler = target_scaler
            self.n_features_in_ = n_features
            self.feature_names_in_ = (
                np.asarray(column_names, dtype=object)
                if column_names is not None
                else None
            )
            self._processed_features = processed_features
            self._est = est
            self._tao_refined_ = False
            if tao_n_runs > 0:
                from sgtlearn.tao import TAO_refine

                TAO_refine(
                    self,
                    X32,
                    y2,
                    sample_weight=sw,
                    check_input=check_input,
                    n_runs=tao_n_runs,
                    lambda_=self.tao_lambda,
                    tao_pair_scale=tao_pair_scale,
                )
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict regression targets for ``X``.

        Returns an array of shape ``(n_samples,)`` for a single output or
        ``(n_samples, n_outputs)`` for multi-output ``y``.
        """
        check_is_fitted(self, attributes=("_est",))
        X = check_array(
            X, accept_sparse=False, dtype=np.float64, ensure_all_finite="allow-nan"
        )
        if self.n_features_in_ is not None and X.shape[1] != self.n_features_in_:
            raise ValueError(
                f"X has {X.shape[1]} features, but SGTRegressor is expecting "
                f"{self.n_features_in_} features as in fit."
            )
        X32 = _as_native_X(X)
        preds = np.asarray(self._est.predict(X32), dtype=np.float64)
        if hasattr(self, "_target_scaler"):
            preds = self._target_scaler.inverse_transform(
                preds.reshape(-1, self.n_outputs_)
            )
        return squeeze_outputs(preds, self.n_outputs_)

    def tree_export(self) -> dict:
        """Return a flat dict snapshot of the fitted tree.

        Consumed by :func:`~sgtlearn.plot_tree` and :func:`~sgtlearn.export_text`.
        Keys: ``num_partitions``, ``num_nodes``, ``root_index``, ``num_outputs``,
        ``criterion``, ``nodes`` (list of per-node dicts). Regression has no
        ``num_classes``.
        """
        check_is_fitted(self, attributes=("_est",))
        if self._est is None:
            raise NotFittedError("This SGTRegressor instance is not fitted yet.")
        tree = _normalize_tree_export(self._est.tree_export())
        if hasattr(self, "_target_scaler"):
            for node in tree["nodes"]:
                if node["value"] is not None:
                    value = self._target_scaler.inverse_transform(
                        np.asarray(node["value"]).reshape(1, -1)
                    )[0]
                    node["value"] = (
                        value.item() if self.n_outputs_ == 1 else value.tolist()
                    )
        return tree
